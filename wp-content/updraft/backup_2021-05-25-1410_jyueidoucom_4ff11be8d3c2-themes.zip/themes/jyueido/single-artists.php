<?php get_header(); ?>

<?php get_template_part( 'mod-page-title' ); ?>


<div class="border-b-1 p-10 text-center">
<?php
$terms = get_the_terms( $post->ID, 'artist' );
if ( $terms && ! is_wp_error( $terms ) ) : 
	$terms_array = array();
	foreach ( $terms as $term ) {
		$terms_array[] = $term->name;
	}
	$artist_categories = join( ", ", $terms_array );
?>
<b class="fz-16"><?php echo $artist_categories; ?></b>
<?php endif; ?></div>


<div class="container">

<?php while ( have_posts() ) : the_post(); ?>
<h2 class="title-1"><?php the_title(); ?><br>
<small class="fz-14"><?php the_field('artists_kana'); ?></small></h2>

<div class="bg-gs-15 p-20 p-xs-0 g-b">

<?php for ( $i = 0; $i < 5; $i++ ) : ?> 
<?php
$group = get_field ('artists_block_' . ($i + 1));   
if ( !empty($group['title']) || !empty($group['contents']) ) : ?>
	<?php if ( $group['image'] ) : ?>
		<div class="box-a box-a-has-image">
			<?php if ( !empty($group['title']) ) :?>
			<h3 class="box-a-title"><?php echo $group['title']; ?></h3>
			<?php endif; ?>
			<div class="box-a-image">
			<img src="<?php echo $site_url; ?>/img/common/placeholder_900x600.png" data-src="<?php echo $group['image']['sizes']['large']; ?>" class="img-responsive g-xs-b-30 lazyload" alt="">
			</div>
			<?php if ( !empty($group['contents']) ) :?>
			<div class="box-a-contents">
			<?php echo $group['contents']; ?>
			</div>
			<?php endif; ?>
		</div>
	<?php else : ?>
		<div class="box-a">
			<?php if ( !empty($group['title']) ) :?>
			<h3 class="box-a-title"><?php echo $group['title']; ?></h3>
			<?php endif; ?>
			<?php if ( !empty($group['contents']) ) :?>
			<div class="box-a-contents">
			<?php echo $group['contents']; ?>
			</div>
			<?php endif; ?>
		</div>
	<?php endif; ?>
<?php endif; ?>
<?php endfor; ?>


</div>
<?php endwhile; ?>

</div>


<div class="bg-gs-15 p-b-1">
<div class="container g-b">
<h2 class="title-1">高価買取作家 カテゴリ一覧</h2>

<?php get_template_part( 'mod-artists-categories' ); ?>

</div>
</div>


<?php get_footer(); ?>
