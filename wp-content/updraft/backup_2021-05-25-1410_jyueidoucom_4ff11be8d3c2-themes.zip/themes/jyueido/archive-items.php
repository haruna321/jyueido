<?php get_header(); ?>

<?php get_template_part( 'mod-page-title' ); ?>


<div class="bg-tx-3">
<div class="container p-t">

<?php get_template_part( 'mod-items-categories' ); ?>

</div>
</div>


<?php get_footer(); ?>
