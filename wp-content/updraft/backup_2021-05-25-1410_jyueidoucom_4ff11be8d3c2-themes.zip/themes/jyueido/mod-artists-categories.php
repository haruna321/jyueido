<?php global $site_url; ?>

<div class="row d-f fxw-w">

<?php
$placeholder = $site_url . '/img/common/placeholder_900x900.png';
$thumb_size = 'thumbnail_320x320';
//タームの取得
$t = 'artist';
$args = array(
	'get' => 'all',
	'meta_key' => 'sort_num',
	'orderby' => (int)'meta_value_num',
	'order' => 'asc'
);
$terms = get_terms( $t, $args );
//タームを出力
if ( !empty($terms) && !is_wp_error($terms) ) : ?>
<?php foreach ( $terms as $term ) : ?>
<div class="col-xs-12 col-sm-6 col-md-4 g-b-30">
<div class="border-b-1 border-b-c-000-015 height-category">
<a href="<?php echo get_term_link( $term->slug, $t ); ?>" class="row g-r--15 g-l--15 link-box-1">
<span class="col-xs-5 p-r-15 p-l-15 d-b g-b-30">
<img src="<?php echo $placeholder; ?>" data-src="<? echo get_field('tax_image_url', $t . '_' . $term->term_id)["sizes"][$thumb_size]; ?>" class="img-responsive img-hover lazyload" alt="">
</span>
<span class="col-xs-7 p-r-15 p-l-15 d-b g-b-30">
<span class="d-b g-b-20"><b class="fz-16"><? echo $term->name; ?></b></span>
<span class="d-b"><? echo $term->description; ?></span>
<!-- 投稿数：<?=$term->count?> -->
</span>
</a>
</div>
</div>

<?php endforeach; ?>
<?php endif; ?>

</div>
