<?php get_header(); ?>

<?php get_template_part( 'mod-page-title' ); ?>


<div class="container g-t g-b">

<?php get_template_part( 'mod-artists-categories' ); ?>

</div>


<?php get_footer(); ?>
